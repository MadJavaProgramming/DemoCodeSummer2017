/** This is where we include a description for the class we are creating, for example:
    Our first class, created as a demo for Java Programming
    @author pwaite    
**/
public class HelloWorld {
    /** The main method to run our program 
        outputs a message to the console
       @param args command line arguments
    */
    public static void main(String[] args){ 
        System.out.println("Hello Everyone!!!");
    }
}

